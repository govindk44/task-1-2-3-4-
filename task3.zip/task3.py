import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import wordnet
import random

# Download necessary NLTK data
nltk.download("punkt")
nltk.download("wordnet")

# Predefined responses for basic chatbot interaction
responses = {
    "greetings": ["Hello!", "Hi there!", "Hey!", "Hi! How can I help you?"],
    "farewell": ["Goodbye!", "See you later!", "Bye! Have a great day!"],
    "default": ["I'm not sure how to respond to that.", "Could you please rephrase?", "Interesting... tell me more!"],
}

# Synonym matching to enhance understanding
def get_synonyms(word):
    synonyms = set()
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.add(lemma.name())
    return synonyms

# Match user input with chatbot responses
def match_response(user_input):
    tokens = word_tokenize(user_input.lower())
    for word in tokens:
        if word in ["hello", "hi", "hey"]:
            return random.choice(responses["greetings"])
        if word in ["bye", "goodbye", "see you"]:
            return random.choice(responses["farewell"])
        
        # Check synonyms for words like "help", "assist"
        synonyms_help = get_synonyms("help")
        if word in synonyms_help:
            return "Sure! Let me know how I can assist you."

    return random.choice(responses["default"])

# Main chatbot loop
def chatbot():
    print("Chatbot: Hello! I am a basic chatbot. Type 'hello' to end the conversation.")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["hello", "exit", "quit"]:
            print("Chatbot:", random.choice(responses["farewell"]))
            break
        response = match_response(user_input)
        print("Chatbot:", response)

if __name__ == "__main__":
    chatbot()
