import requests
from prettytable import PrettyTable

API_KEY = "your_alpha_vantage_api_key"
BASE_URL = "https://www.alphavantage.co/query"


portfolio = {}

def fetch_stock_data(symbol):
    """
    Fetch real-time stock data from Alpha Vantage API.
    """
    params = {
        "function": "GLOBAL_QUOTE",
        "symbol": symbol,
        "apikey": API_KEY,
    }
    response = requests.get(BASE_URL, params=params)
    data = response.json()

    # Check if the stock symbol is valid
    if "Global Quote" in data:
        quote = data["Global Quote"]
        return {
            "symbol": quote["01. symbol"],
            "price": float(quote["05. price"]),
            "change": float(quote["09. change"]),
            "percent_change": quote["10. change percent"],
        }
    else:
        print(f"Error: Could not fetch data for {symbol}.")
        return None

def add_stock(symbol, quantity):
    """
    Add a stock to the portfolio.
    """
    stock_data = fetch_stock_data(symbol)
    if stock_data:
        if symbol in portfolio:
            portfolio[symbol]["quantity"] += quantity
        else:
            portfolio[symbol] = {"quantity": quantity, "price": stock_data["price"]}
        print(f"Added {quantity} shares of {symbol} at ${stock_data['price']} each.")

def remove_stock(symbol):
    """
    Remove a stock from the portfolio.
    """
    if symbol in portfolio:
        del portfolio[symbol]
        print(f"Removed {symbol} from the portfolio.")
    else:
        print(f"Stock {symbol} not found in the portfolio.")

def view_portfolio():
    """
    Display the portfolio with real-time performance.
    """
    if not portfolio:
        print("Your portfolio is empty.")
        return

    table = PrettyTable()
    table.field_names = ["Symbol", "Quantity", "Current Price", "Change (%)", "Total Value ($)"]

    total_value = 0
    for symbol, details in portfolio.items():
        stock_data = fetch_stock_data(symbol)
        if stock_data:
            current_value = details["quantity"] * stock_data["price"]
            total_value += current_value
            table.add_row([
                symbol,
                details["quantity"],
                f"${stock_data['price']:.2f}",
                stock_data["percent_change"],
                f"${current_value:.2f}",
            ])

    print(table)
    print(f"Total Portfolio Value: ${total_value:.2f}")

def main():
    """
    Main menu for the stock portfolio tracker.
    """
    while True:
        print("\nStock Portfolio Tracker")
        print("1. Add Stock")
        print("2. Remove Stock")
        print("3. View Portfolio")
        print("4. Exit")
        choice = input("Choose an option: ")

        if choice == "1":
            symbol = input("Enter stock symbol: ").upper()
            quantity = int(input("Enter quantity: "))
            add_stock(symbol, quantity)
        elif choice == "2":
            symbol = input("Enter stock symbol to remove: ").upper()
            remove_stock(symbol)
        elif choice == "3":
            view_portfolio()
        elif choice == "4":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
