import os
import shutil

def organize_files(directory):
    """
    Organize files in the specified directory into folders based on file extensions.
    """
    if not os.path.exists(directory):
        print(f"The directory '{directory}' does not exist.")
        return

    # List all files in the directory
    files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]

    if not files:
        print("No files to organize.")
        return

    # Process each file
    for file in files:
        file_path = os.path.join(directory, file)
        # Get the file extension
        file_extension = file.split('.')[-1] if '.' in file else "no_extension"
        folder_name = file_extension.upper() + "_Files"

        # Create a folder for the extension if it doesn't exist
        folder_path = os.path.join(directory, folder_name)
        if not os.path.exists(folder_path):
            os.mkdir(folder_path)

        # Move the file to the corresponding folder
        shutil.move(file_path, os.path.join(folder_path, file))

    print("Files have been organized.")

if __name__ == "__main__":
    # Specify the directory you want to organize
    target_directory = input("Enter the path of the directory to organize: ").strip()
    organize_files(target_directory)
