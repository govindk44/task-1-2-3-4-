import random

def game():

    words = ["python", "hangman", "programming", "developer", "challenge"]

    wordtoguess = random.choice(words)
    guessed_word = ["_"] * len(wordtoguess)
    guessed_letters = set()
    attempts = 6  

    print("Welcome to Game!")
    print(f"The word has {len(wordtoguess)} letters.")
    print(" ".join(guessed_word))

    while attempts > 0 and "_" in guessed_word:
        guess = input("\nGuess a letter: ").lower()


        if len(guess) != 1 or not guess.isalpha():
            print("Please guess a single valid letter.")
            continue

        if guess in guessed_letters:
            print("You already guessed that letter. Try another one.")
            continue

        guessed_letters.add(guess)

        if guess in wordtoguess:
            print(f"Good job! '{guess}' is in the word.")
            for idx, char in enumerate(wordtoguess):
                if char == guess:
                    guessed_word[idx] = char
        else:
            attempts -= 1
            print(f"Oops! '{guess}' is not in the word. Attempts left: {attempts}")

        print(" ".join(guessed_word))

    if "_" not in guessed_word:
        print("\nCongratulations! You guessed the word:", wordtoguess)
    else:
        print("\nYou're out of attempts! The word was:", wordtoguess)

if __name__ == "__main__":
    game()
